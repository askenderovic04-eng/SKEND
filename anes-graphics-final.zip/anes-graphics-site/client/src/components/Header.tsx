/*
 * ANES GRAPHICS — Header Component
 * Style: Barre gris et blanc minimaliste, collée en haut, fixe
 * Logo à gauche, navigation à droite (Accueil + Discord)
 */

// ============================================================
// CONFIGURATION FACILE — Modifiez ces valeurs ici
// ============================================================
const SITE_NAME = "Anes Graphics";
const DISCORD_LINK = "https://discord.gg/GEgBQjeGy4";
// ============================================================

export default function Header() {
  const scrollToTop = (e: React.MouseEvent) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50"
      style={{
        backgroundColor: "rgba(248,248,248,0.02)",
        borderBottom: "none",
        backdropFilter: "blur(4px)",
      }}
    >
      <div className="container">
        <div className="flex items-center justify-between h-14">
          {/* Logo / Nom du site */}
          <a
            href="/"
            onClick={scrollToTop}
            className="flex items-center gap-2 group"
            style={{ textDecoration: "none" }}
          >
            {/* Accent gris carré */}
            <span
              style={{
                display: "inline-block",
                width: "4px",
                height: "22px",
                backgroundColor: "#ffffff",
                borderRadius: "1px",
                transition: "height 0.2s ease",
              }}
              className="group-hover:h-6"
            />
            <span
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 800,
                fontSize: "1.3rem",
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "#ffffff",
              }}
            >
              {SITE_NAME}
            </span>
          </a>

          {/* Navigation */}
          <nav className="flex items-center gap-6">
            {/* Accueil */}
            <a
              href="/"
              onClick={scrollToTop}
              style={{
                fontFamily: "'Rajdhani', sans-serif",
                fontWeight: 600,
                fontSize: "0.95rem",
                textTransform: "uppercase",
                letterSpacing: "0.12em",
                color: "#ffffff",
                textDecoration: "none",
                transition: "color 0.2s ease",
                position: "relative",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.color = "#cccccc";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.color = "#ffffff";
              }}
            >
              Accueil
            </a>

            {/* Discord */}
            <a
              href={DISCORD_LINK}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                fontFamily: "'Rajdhani', sans-serif",
                fontWeight: 700,
                fontSize: "0.95rem",
                textTransform: "uppercase",
                letterSpacing: "0.12em",
                color: "#ffffff",
                textDecoration: "none",
                padding: "6px 16px",
                border: "1px solid rgba(255,255,255,0.3)",
                borderRadius: "2px",
                transition: "all 0.2s ease",
                display: "flex",
                alignItems: "center",
                gap: "6px",
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLElement;
                el.style.backgroundColor = "rgba(255,255,255,0.1)";
                el.style.borderColor = "#ffffff";
                el.style.boxShadow = "0 0 12px rgba(255,255,255,0.3)";
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLElement;
                el.style.backgroundColor = "transparent";
                el.style.borderColor = "rgba(255,255,255,0.3)";
                el.style.boxShadow = "none";
              }}
            >
              {/* Discord icon SVG */}
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.032.054a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
              </svg>
              Discord
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}
