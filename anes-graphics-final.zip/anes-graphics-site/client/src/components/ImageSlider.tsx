/*
 * ANES GRAPHICS — Image Slider Component
 * Style: Bloc interactif gaming premium avec navigation
 * Click au centre → ouvre Discord
 * Flèches visibles au survol pour naviguer
 */

import { useState, useCallback } from "react";

// ============================================================
// CONFIGURATION FACILE — Modifiez les 5 images ici
// Remplacez les URLs par vos propres images
// ============================================================
export const SLIDER_IMAGES = [
  {
    src: "https://media.discordapp.net/attachments/1481603541490602045/1481672396183437322/IMG_1153.png?ex=69b8c7b3&is=69b77633&hm=df13863629b18701251171b026ced1f6f257418abcf0df6d724377f5a5b82a03&=&format=webp&quality=lossless",
    alt: "Aperçu dossier FiveM — Image 1",
  },
  {
    src: "https://media.discordapp.net/attachments/1481603671837114509/1481672577985548459/IMG_1150.png?ex=69b8c7de&is=69b7765e&hm=5fb9a3596f899c7c80e581476f8bd90974a12dcb4fd47a52e9b1ca799956bf8a&=&format=webp&quality=lossless&width=550&height=309",
    alt: "Aperçu dossier FiveM — Image 2",
  },
  {
    src: "https://media.discordapp.net/attachments/1481603671837114509/1481672692477464647/IMG_1156.png?ex=69b8c7fa&is=69b7767a&hm=10088a5893bd89e883f261fb336c198bc3aa8cce7d94fa3103aaa88baba61cb6&=&format=webp&quality=lossless",
    alt: "Aperçu dossier FiveM — Image 3",
  },
  {
    src: "https://media.discordapp.net/attachments/1481603541490602045/1481672351874551989/fb_mara.png?ex=69b8c7a8&is=69b77628&hm=eef9b46d1b8258f2b872bf978f4dbd66ed1fc5003154cc397cea579cdc533bfa&=&format=webp&quality=lossless&width=550&height=309",
    alt: "Aperçu dossier FiveM — Image 4",
  },
  {
    src: "https://media.discordapp.net/attachments/1481603541490602045/1481672440190074890/9392E934-7424-44B6-A33F-69DF93900C9B.png?ex=69b8c7bd&is=69b7763d&hm=8329d7284e79ec488101adbb7e6b739cbb39b089db64ebc55cbf85cb3e8d57f3&=&format=webp&quality=lossless",
    alt: "Aperçu dossier FiveM — Image 5",
  },
];

// Lien Discord — modifiable ici
const DISCORD_LINK = "https://discord.gg/GEgBQjeGy4";
// ============================================================

export default function ImageSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goTo = useCallback(
    (index: number) => {
      if (isTransitioning) return;
      setIsTransitioning(true);
      setCurrentIndex((index + SLIDER_IMAGES.length) % SLIDER_IMAGES.length);
      setTimeout(() => setIsTransitioning(false), 350);
    },
    [isTransitioning]
  );

  const goNext = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      goTo(currentIndex + 1);
    },
    [currentIndex, goTo]
  );

  const goPrev = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      goTo(currentIndex - 1);
    },
    [currentIndex, goTo]
  );

  const handleCenterClick = () => {
    window.open(DISCORD_LINK, "_blank", "noopener,noreferrer");
  };

  const [isHovering, setIsHovering] = useState(false);

  return (
    <div className="flex flex-col gap-3 p-6" style={{
      border: "4px solid #333333",
      borderRadius: "0px",
      background: isHovering ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.15)",
      boxShadow: isHovering ? "12px 12px 0px rgba(0,0,0,0.25), -2px -2px 0px rgba(255,255,255,0.8) inset" : "8px 8px 0px rgba(0,0,0,0.15), -2px -2px 0px rgba(255,255,255,0.8) inset",
      backdropFilter: "blur(3px)",
      minHeight: "700px",
      maxHeight: "700px",
      overflow: "auto",
      transform: isHovering ? "translateY(-4px)" : "translateY(0)",
      transition: "all 0.3s ease",
      cursor: "pointer",
    }}
    onMouseEnter={() => setIsHovering(true)}
    onMouseLeave={() => setIsHovering(false)}
    >
      {/* Titre de la section */}
      <div className="section-title">Aperçu du dossier</div>

      {/* Bloc slider principal */}
      <div
        className="slider-container relative"
        style={{
          border: "1px solid rgba(0,0,0,0.15)",
          borderRadius: "3px",
          overflow: "hidden",
          cursor: "pointer",
          transition: "border-color 0.3s ease, box-shadow 0.3s ease",
          boxShadow: isHovered
            ? "0 0 25px rgba(100,100,100,0.15), 0 0 50px rgba(100,100,100,0.05)"
            : "0 0 15px rgba(0,0,0,0.08)",
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleCenterClick}
      >
        {/* Image principale */}
        <div
          style={{
            position: "relative",
            width: "100%",
            paddingBottom: "75%", /* ratio 4:3 */
            overflow: "hidden",
          }}
        >
          <img
            key={currentIndex}
            src={SLIDER_IMAGES[currentIndex].src}
            alt={SLIDER_IMAGES[currentIndex].alt}
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              objectFit: "cover",
              transition: "opacity 0.35s ease",
              opacity: isTransitioning ? 0 : 1,
            }}
          />

          {/* Overlay sombre au hover pour indiquer le clic Discord */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: "rgba(0,0,0,0.3)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: isHovered ? 1 : 0,
              transition: "opacity 0.3s ease",
              pointerEvents: "none",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "8px",
              }}
            >
              {/* Discord icon */}
              <svg
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="#666666"
                style={{ filter: "drop-shadow(0 0 8px rgba(100,100,100,0.5))" }}
              >
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.032.054a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
              </svg>
              <span
                style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontWeight: 700,
                  fontSize: "1rem",
                  textTransform: "uppercase",
                  letterSpacing: "0.1em",
                  color: "#1a1a1a",
                  textShadow: "0 0 10px rgba(255,255,255,0.5)",
                }}
              >
                Rejoindre le Discord
              </span>
            </div>
          </div>

          {/* Flèche GAUCHE — visible au hover */}
          <button
            className="slider-arrow"
            onClick={goPrev}
            aria-label="Image précédente"
            style={{
              position: "absolute",
              left: "12px",
              top: "50%",
              transform: "translateY(-50%)",
              background: "rgba(255,255,255,0.9)",
              border: "1px solid rgba(0,0,0,0.2)",
              borderRadius: "2px",
              width: "36px",
              height: "36px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#666666",
              zIndex: 10,
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget;
              el.style.background = "rgba(100,100,100,0.15)";
              el.style.borderColor = "#666666";
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget;
              el.style.background = "rgba(255,255,255,0.9)";
              el.style.borderColor = "rgba(0,0,0,0.2)";
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>

          {/* Flèche DROITE — visible au hover */}
          <button
            className="slider-arrow"
            onClick={goNext}
            aria-label="Image suivante"
            style={{
              position: "absolute",
              right: "12px",
              top: "50%",
              transform: "translateY(-50%)",
              background: "rgba(255,255,255,0.9)",
              border: "1px solid rgba(0,0,0,0.2)",
              borderRadius: "2px",
              width: "36px",
              height: "36px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#666666",
              zIndex: 10,
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget;
              el.style.background = "rgba(100,100,100,0.15)";
              el.style.borderColor = "#666666";
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget;
              el.style.background = "rgba(255,255,255,0.9)";
              el.style.borderColor = "rgba(0,0,0,0.2)";
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>

          {/* Badge numéro de slide */}
          <div
            style={{
              position: "absolute",
              bottom: "10px",
              right: "12px",
              background: "rgba(255,255,255,0.95)",
              border: "1px solid rgba(0,0,0,0.15)",
              borderRadius: "2px",
              padding: "2px 8px",
              fontFamily: "'Rajdhani', sans-serif",
              fontWeight: 600,
              fontSize: "0.75rem",
              color: "#666666",
              letterSpacing: "0.05em",
            }}
          >
            {currentIndex + 1} / {SLIDER_IMAGES.length}
          </div>
        </div>

        {/* Barre de progression */}
        <div
          style={{
            height: "3px",
            background: "rgba(0,0,0,0.08)",
            position: "relative",
          }}
        >
          <div
            style={{
              height: "100%",
              background: "linear-gradient(90deg, #999999, #666666)",
              width: `${((currentIndex + 1) / SLIDER_IMAGES.length) * 100}%`,
              transition: "width 0.35s ease",
            }}
          />
        </div>
      </div>

      {/* Dots de navigation */}
      <div className="flex items-center justify-center gap-2 mt-1">
        {SLIDER_IMAGES.map((_, i) => (
          <button
            key={i}
            onClick={(e) => {
              e.stopPropagation();
              goTo(i);
            }}
            aria-label={`Aller à l'image ${i + 1}`}
            style={{
              width: i === currentIndex ? "24px" : "8px",
              height: "4px",
              borderRadius: "2px",
              background: i === currentIndex ? "#666666" : "rgba(0,0,0,0.15)",
              border: "none",
              padding: 0,
              transition: "all 0.3s ease",
              cursor: "pointer",
            }}
          />
        ))}
      </div>

      {/* Texte indicatif */}
      <p
        style={{
          fontFamily: "'Rajdhani', sans-serif",
          fontSize: "0.8rem",
          color: "#999999",
          textAlign: "center",
          letterSpacing: "0.05em",
          marginTop: "4px",
        }}
      >
        Clique sur l'image pour rejoindre le Discord
      </p>
    </div>
  );
}
