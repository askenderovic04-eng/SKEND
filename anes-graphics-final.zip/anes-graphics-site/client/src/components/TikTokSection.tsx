/*
 * ANES GRAPHICS — TikTok Section Component
 * Style: Bloc gaming premium avec miniature et lien vers TikTok
 * Solution de secours simple et facilement modifiable
 */

import { useState } from "react";

// ============================================================
// CONFIGURATION FACILE — Modifiez ces valeurs ici
// ============================================================
const TIKTOK_CONFIG = {
  // Lien vers votre compte TikTok ou votre dernière vidéo
  link: "https://vm.tiktok.com/ZNRHwHxbd/",

  // Miniature de la vidéo — remplacez par l'URL de votre miniature
  // Vous pouvez faire une capture d'écran de votre TikTok et l'uploader
  thumbnail: "https://media.discordapp.net/attachments/1481603671837114509/1481672505453318275/IMG_1149.png?ex=69b8c7cd&is=69b7764d&hm=4224b1f57f51b689fae685fe3e609bfde4fd461a6288013eedb84d9ccfe7ed44&=&format=webp&quality=lossless&width=550&height=313",

  // Titre ou description de la vidéo
  title: "Dernier dossier FiveM disponible 🔥",

  // Texte du bouton
  buttonText: "Voir le TikTok",

  // Nom du compte
  username: "@.bftss",
};
// ============================================================

export default function TikTokSection() {
  const [isHovered, setIsHovered] = useState(false);

  const [isHovering2, setIsHovering2] = useState(false);

  return (
    <div className="flex flex-col gap-3 p-6" style={{
      border: "4px solid #333333",
      borderRadius: "0px",
      background: isHovering2 ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.15)",
      boxShadow: isHovering2 ? "12px 12px 0px rgba(0,0,0,0.25), -2px -2px 0px rgba(255,255,255,0.8) inset" : "8px 8px 0px rgba(0,0,0,0.15), -2px -2px 0px rgba(255,255,255,0.8) inset",
      backdropFilter: "blur(3px)",
      minHeight: "700px",
      maxHeight: "700px",
      overflow: "auto",
      transform: isHovering2 ? "translateY(-4px)" : "translateY(0)",
      transition: "all 0.3s ease",
      cursor: "pointer",
    }}
    onMouseEnter={() => setIsHovering2(true)}
    onMouseLeave={() => setIsHovering2(false)}
    >
      {/* Titre de la section */}
      <div className="section-title">Dernier TikTok</div>

      {/* Carte TikTok */}
      <div
        className="tiktok-card"
        style={{
          border: "1px solid rgba(0,0,0,0.15)",
          borderRadius: "3px",
          overflow: "hidden",
          transition: "border-color 0.3s ease, box-shadow 0.3s ease",
          boxShadow: isHovered
            ? "0 0 25px rgba(100,100,100,0.15), 0 0 50px rgba(100,100,100,0.05)"
            : "0 0 15px rgba(0,0,0,0.08)",
          background: "#fafafa",
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Miniature avec overlay play */}
        <a
          href={TIKTOK_CONFIG.link}
          target="_blank"
          rel="noopener noreferrer"
          style={{ display: "block", position: "relative", textDecoration: "none" }}
        >
          <div
            style={{
              position: "relative",
              width: "100%",
              paddingBottom: "75%",
              overflow: "hidden",
            }}
          >
            <img
              src={TIKTOK_CONFIG.thumbnail}
              alt={TIKTOK_CONFIG.title}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                objectFit: "cover",
                transition: "transform 0.4s ease",
                transform: isHovered ? "scale(1.04)" : "scale(1)",
              }}
            />

            {/* Overlay sombre */}
            <div
              style={{
                position: "absolute",
                inset: 0,
                background: isHovered
                  ? "rgba(0,0,0,0.2)"
                  : "rgba(0,0,0,0.1)",
                transition: "background 0.3s ease",
              }}
            />

            {/* Bouton Play centré */}
            <div
              className="tiktok-play-overlay"
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                opacity: isHovered ? 1 : 0.7,
                transition: "opacity 0.3s ease",
              }}
            >
              <div
                style={{
                  width: "64px",
                  height: "64px",
                  borderRadius: "50%",
                  background: "rgba(255,255,255,0.95)",
                  border: "2px solid #666666",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: isHovered
                    ? "0 0 20px rgba(100,100,100,0.4)"
                    : "0 0 10px rgba(100,100,100,0.2)",
                  transition: "all 0.3s ease",
                  transform: isHovered ? "scale(1.1)" : "scale(1)",
                }}
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="#666666"
                  style={{ marginLeft: "3px" }}
                >
                  <polygon points="5,3 19,12 5,21" />
                </svg>
              </div>
            </div>

            {/* Badge TikTok */}
            <div
              style={{
                position: "absolute",
                top: "10px",
                left: "10px",
                background: "rgba(255,255,255,0.95)",
                border: "1px solid rgba(0,0,0,0.15)",
                borderRadius: "2px",
                padding: "3px 8px",
                display: "flex",
                alignItems: "center",
                gap: "5px",
              }}
            >
              {/* TikTok icon */}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#1a1a1a">
                <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.27 8.27 0 004.84 1.56V6.79a4.85 4.85 0 01-1.07-.1z"/>
              </svg>
              <span
                style={{
                  fontFamily: "'Rajdhani', sans-serif",
                  fontWeight: 600,
                  fontSize: "0.7rem",
                  color: "#1a1a1a",
                  letterSpacing: "0.05em",
                  textTransform: "uppercase",
                }}
              >
                TikTok
              </span>
            </div>
          </div>
        </a>

        {/* Infos sous la miniature */}
        <div style={{ padding: "14px 16px" }}>
          {/* Compte */}
          <div
            style={{
              fontFamily: "'Rajdhani', sans-serif",
              fontWeight: 600,
              fontSize: "0.8rem",
              color: "#666666",
              letterSpacing: "0.05em",
              marginBottom: "6px",
            }}
          >
            {TIKTOK_CONFIG.username}
          </div>

          {/* Titre de la vidéo */}
          <p
            style={{
              fontFamily: "'Rajdhani', sans-serif",
              fontWeight: 500,
              fontSize: "0.95rem",
              color: "#333333",
              lineHeight: 1.4,
              marginBottom: "14px",
            }}
          >
            {TIKTOK_CONFIG.title}
          </p>

          {/* Bouton Voir le TikTok */}
          <a
            href={TIKTOK_CONFIG.link}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              width: "100%",
              padding: "10px 16px",
              background: "transparent",
              border: "1px solid rgba(0,0,0,0.2)",
              borderRadius: "2px",
              fontFamily: "'Barlow Condensed', sans-serif",
              fontWeight: 700,
              fontSize: "0.95rem",
              textTransform: "uppercase",
              letterSpacing: "0.1em",
              color: "#666666",
              textDecoration: "none",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget;
              el.style.background = "rgba(100,100,100,0.1)";
              el.style.borderColor = "#666666";
              el.style.boxShadow = "0 0 12px rgba(100,100,100,0.15)";
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget;
              el.style.background = "transparent";
              el.style.borderColor = "rgba(0,0,0,0.2)";
              el.style.boxShadow = "none";
            }}
          >
            {/* TikTok icon */}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.27 8.27 0 004.84 1.56V6.79a4.85 4.85 0 01-1.07-.1z"/>
            </svg>
            {TIKTOK_CONFIG.buttonText}
          </a>
        </div>
      </div>

      {/* Note de configuration */}
      <p
        style={{
          fontFamily: "'Rajdhani', sans-serif",
          fontSize: "0.75rem",
          color: "#999999",
          textAlign: "center",
          letterSpacing: "0.03em",
          marginTop: "4px",
        }}
      >
        Clique sur l'image ou le bouton pour voir le TikTok
      </p>
    </div>
  );
}
