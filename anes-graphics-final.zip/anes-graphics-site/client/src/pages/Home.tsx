/*
 * ANES GRAPHICS — Page d'accueil principale
 * Style: Street Forge — Gris et Blanc Premium
 * Layout: Header fixe + Hero background graffiti + 2 colonnes (slider + TikTok)
 *
 * ============================================================
 * CONFIGURATION RAPIDE — Modifiez ces constantes pour personnaliser
 * ============================================================
 * DISCORD_LINK     → Lien Discord
 * TIKTOK_LINK      → Lien TikTok
 * BG_IMAGE_URL     → Image de fond principale
 * SLIDER_IMAGES    → Dans ImageSlider.tsx
 * TIKTOK_CONFIG    → Dans TikTokSection.tsx
 * ============================================================
 */

import Header from "@/components/Header";
import ImageSlider from "@/components/ImageSlider";
import TikTokSection from "@/components/TikTokSection";

// ============================================================
// CONFIGURATION FACILE
// ============================================================
const DISCORD_LINK = "https://discord.gg/GEgBQjeGy4";

// Image de fond principale — remplacez par votre propre image graffiti
const BG_IMAGE_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663443143341/QwHVMr5dEvUXkasWTY5oGk/pasted_file_TB9XcZ_image_26a5aa1b.png";
// ============================================================

export default function Home() {
  return (
    <div
      className="grain-overlay"
      style={{
        minHeight: "100vh",
        backgroundColor: "#f5f5f5",
        position: "relative",
      }}
    >
      {/* Header fixe */}
      <Header />

      {/* Hero Section — fond graffiti plein écran */}
      <section
        style={{
          position: "relative",
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          paddingTop: "56px", /* hauteur du header */
        }}
      >
        {/* Image de fond floutée */}
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: `url(${BG_IMAGE_URL})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            backgroundAttachment: "fixed",
            zIndex: 0,
            filter: "blur(0.5px)",
          }}
        />

        {/* Overlay semi-transparent pour lisibilité */}
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(255,255,255,0.4)",
            zIndex: 1,
          }}
        />

        {/* Contenu principal */}
        <div
          style={{
            position: "relative",
            zIndex: 2,
            flex: 1,
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* Bandeau titre central */}
          <div
            className="fade-in-up"
            style={{
              textAlign: "center",
              padding: "24px 16px 16px",
              background: "transparent",
            }}
          >
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "16px",
                marginBottom: "8px",
              }}
            >
              <div
                style={{
                  height: "1px",
                  width: "60px",
                  background: "linear-gradient(90deg, transparent, #666666)",
                }}
              />
              <span
                style={{
                  fontFamily: "'Rajdhani', sans-serif",
                  fontWeight: 800,
                  fontSize: "1.2rem",
                  textTransform: "uppercase",
                  letterSpacing: "0.25em",
                  color: "#000000",
                }}
              >
                Dossiers FiveM / GTA RP
              </span>
              <div
                style={{
                  height: "1px",
                  width: "60px",
                  background: "linear-gradient(90deg, #666666, transparent)",
                }}
              />
            </div>

            <h1
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 800,
                fontSize: "1rem",
                color: "#ffffff",
                textTransform: "uppercase",
                letterSpacing: "0.15em",
                lineHeight: 1,
                textShadow: "0 2px 8px rgba(0,0,0,0.08)",
                marginBottom: "12px",
              }}
            >
              Anes{" "}
              <span style={{ color: "#cccccc" }}>Graphics</span>
            </h1>



            {/* CTA Discord principal */}
            <a
              href={DISCORD_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="discord-btn-pulse"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "10px",
                padding: "12px 28px",
                background: "linear-gradient(135deg, #999999, #666666)",
                border: "none",
                borderRadius: "2px",
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 700,
                fontSize: "1rem",
                textTransform: "uppercase",
                letterSpacing: "0.12em",
                color: "#ffffff",
                textDecoration: "none",
                transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget;
                el.style.transform = "translateY(-2px)";
                el.style.boxShadow = "0 8px 25px rgba(100,100,100,0.25)";
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget;
                el.style.transform = "translateY(0)";
                el.style.boxShadow = "";
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.032.054a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
              </svg>
              Rejoindre le Discord
            </a>
          </div>

          {/* Séparateur avec ligne grise */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "16px",
              padding: "8px 16px",
              maxWidth: "1400px",
              margin: "0 auto",
              width: "100%",
              background: "transparent",
            }}
          >
            <div style={{ flex: 1, height: "1px", background: "rgba(255,255,255,0.1)" }}
            />
            <span
              style={{
                fontFamily: "'Barlow Condensed', sans-serif",          fontWeight: 700,
                fontSize: "0.7rem",
                textTransform: "uppercase",
                letterSpacing: "0.2em",
                color: "rgba(0,0,0,0.3)",
              }}
            >
              ◆
            </span>
            <div style={{ flex: 1, height: "1px", background: "rgba(255,255,255,0.1)" }} />
          </div>

          {/* Section 2 colonnes */}
          <div
            className="container"
            style={{
              paddingTop: "16px",
              paddingBottom: "24px",
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "32px",
                alignItems: "stretch",
              }}
              className="main-grid"
            >
              {/* Colonne gauche — Aperçu dossier */}
              <div className="fade-in-up-delay-1">
                <ImageSlider />
              </div>

              {/* Colonne droite — TikTok */}
              <div className="fade-in-up-delay-2">
                <TikTokSection />
              </div>
            </div>
          </div>

          {/* Footer */}
          <footer
            style={{
              position: "relative",
              zIndex: 2,
              borderTop: "1px solid rgba(255,255,255,0.1)",
              padding: "20px 16px",
              textAlign: "center",
              background: "transparent",
            }}
          >
            <p
              style={{
                fontFamily: "'Rajdhani', sans-serif",
                fontWeight: 500,
                fontSize: "0.8rem",
                color: "#cccccc",
                letterSpacing: "0.08em",
                textTransform: "uppercase",
              }}
            >
              © 2025 Anes Graphics — Tous droits réservés
            </p>
          </footer>
        </div>
      </section>

      {/* Responsive styles */}
      <style>{`
        @media (max-width: 768px) {
          .main-grid {
            grid-template-columns: 1fr !important;
            gap: 40px !important;
          }
        }
      `}</style>
    </div>
  );
}
