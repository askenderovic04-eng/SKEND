# Anes Graphics — Concepts de Design

## Concept Choisi : "Street Forge" — Urban Dark Premium

### Design Movement
Street Art Industriel × Gaming Premium — Fusion entre l'esthétique graffiti urbaine et l'interface gaming haut de gamme.

### Core Principles
1. **Noir absolu comme base** — Fond quasi-noir (#0a0a0a) avec textures de briques et graffiti visibles en arrière-plan
2. **Orange brûlé comme accent unique** — #FF6B00 / #FF8C00 pour tous les éléments interactifs et accents visuels
3. **Typographie contrastée** — Barlow Condensed Bold pour les titres (impact street), Rajdhani pour le corps (gaming clean)
4. **Asymétrie intentionnelle** — Layout 2 colonnes déséquilibrées (55/45) pour un rendu dynamique

### Color Philosophy
- **#0a0a0a** — Fond principal, noir profond comme l'asphalte la nuit
- **#1a1a1a / #222222** — Cartes et blocs, légèrement plus clair pour la profondeur
- **#FF6B00** — Orange brûlé, accent principal (énergie, street, gaming)
- **#FF8C00** — Orange clair pour les hovers et glows
- **#FFFFFF** — Texte principal sur fond sombre
- **#888888** — Texte secondaire, sous-titres

### Layout Paradigm
- Header fixe gris sombre (#1c1c1c) collé en haut, minimaliste
- Section principale en 2 colonnes asymétriques (55% gauche / 45% droite)
- Fond hero avec image graffiti "Anes Graphics" en plein écran avec overlay sombre
- Pas de centrage générique — tout est ancré à gauche ou structuré en blocs

### Signature Elements
1. **Bordures orange avec effet glow** sur les cartes et blocs interactifs
2. **Lignes diagonales / cuts** pour séparer les sections (clip-path)
3. **Grain texture subtil** en overlay sur le fond pour l'effet urbain

### Interaction Philosophy
- Hover sur le slider : flèche de navigation apparaît avec transition fluide
- Hover sur les cartes : bordure orange s'illumine (box-shadow glow)
- Click sur l'aperçu dossier : ouvre Discord directement
- Transitions CSS 300ms ease-out pour tout

### Animation
- Entrée des sections : fade-in + translateY(20px) au chargement
- Slider : transition slide horizontale fluide (300ms ease-in-out)
- Header : aucune animation, statique et solide
- Hover glow : transition 200ms sur box-shadow

### Typography System
- **Titres H1/H2** : Barlow Condensed, 700, uppercase, letter-spacing: 0.05em
- **Navigation** : Rajdhani, 600, uppercase, letter-spacing: 0.1em
- **Corps** : Rajdhani, 400, taille 16px
- **Accents** : Barlow Condensed, 800, orange, uppercase
